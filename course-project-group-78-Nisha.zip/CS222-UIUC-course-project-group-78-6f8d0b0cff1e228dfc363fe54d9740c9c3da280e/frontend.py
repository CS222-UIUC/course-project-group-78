# need to figure out how to connect godot with front end

# need something that takes in a mp3 file and send it to backend

# need something that takes the beatmap file from backend

'''
Couldn't figure out how to connect Godot and Git yet. Have a basic UI up and running with
a main menu and gampelay scene. There are buttons you can click to switch between the two. 
Inlcuded button scripts below, don't know how to turn the whole project to code yet, will 
try to have that done by next week.

---------------------
extends Node2D

func _on_start_button_pressed():
	get_tree().change_scene("res://scenes/gameplay_scene/gameplay_scene.tscn")

---------------------
extends Node2D

func _on_quit_button_pressed():
	get_tree().change_scene("res://scenes/main_scene/main_scene.tscn")

'''

# Kevin was here

def read_file():
    '''
    testing
    :return:
    '''
